<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Exam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<body>

<div class="container">
<h1 class="test-center pt-4"> Table<strong class="text-danger"> Question 2 </strong></h1>

<a href="" class="btn btn-success btn-sm" title="add new product">new Product</a>

<div class="row py-2">
    <div class="col-md-6">
        <div class="form-group">
            <form method="get" action="/search">
                <div class="input-group">
                    <input class="form-control" name="search" placeholder="search for product's name or variant">
                    <button type="submit" class="btn btn-primary" > Searching</button>
                </div>
            </form>
        </div>
    </div>
</div>

</div>

    <table class="table table-hover">
    <thead>
        <tr>
            <th scope="col">Product</th>
            <th scope="col">variant</th>
            <th scope="col">category</th>
            <th scope="col">price</th>
            <th scope="col">stock</th>
            <th scope="col">status</th>
        </tr>

    </thead>

    <tbody>
        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($Product->name); ?></th>
            <td><?php echo e($Product->variant); ?></td>
            <td><?php echo e($Product->category); ?></td>
            <td>IDR <?php echo e($Product->price); ?></td>
            <td><?php echo e($Product->stock); ?> pcs</td>
            <td><?php echo e($Product->status); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>









</body>
</html>
<?php /**PATH C:\Users\nasser\OneDrive\Desktop\golang\table_web\resources\views/index.blade.php ENDPATH**/ ?>