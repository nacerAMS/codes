<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Exam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<body>

<div class="container">
<h1 class="test-center pt-4"> Table<strong class="text-danger"> Question 2 </strong></h1>

<a href="" class="btn btn-success btn-sm" title="add new product">new Product</a>

<div class="row py-2">
    <div class="col-md-6">
        <div class="form-group">
            <form method="get" action="/search">
                <div class="input-group">
                    <input class="form-control" name="search" placeholder="search for product's name or variant">
                    <button type="submit" class="btn btn-primary" > Searching</button>
                </div>
            </form>
        </div>
    </div>
</div>

</div>

    <table class="table table-hover">
    <thead>
        <tr>
            <th scope="col">Product</th>
            <th scope="col">variant</th>
            <th scope="col">category</th>
            <th scope="col">price</th>
            <th scope="col">stock</th>
            <th scope="col">status</th>
        </tr>

    </thead>

    <tbody>
        @foreach($Products as $Product)
        <tr>
            <th scope="row">{{$Product->name}}</th>
            <td>{{$Product->variant}}</td>
            <td>{{$Product->category}}</td>
            <td>IDR {{$Product->price}}</td>
            <td>{{$Product->stock}} pcs</td>
            <td>{{$Product->status}}</td>
        </tr>
        @endforeach
    </tbody>
    </table>









</body>
</html>
